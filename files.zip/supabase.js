// ════════════════════════════════════════════════════════
//  BEE Congruence — Client Supabase
//  Remplacez les deux valeurs ci-dessous par celles de
//  votre projet sur https://supabase.com/dashboard
// ════════════════════════════════════════════════════════

const SUPABASE_URL  = 'https://VOTRE_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'VOTRE_ANON_KEY';

// Import Supabase via CDN (chargé dans chaque page HTML)
// <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.min.js"></script>
const _supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON);

// ── Auth helpers ──────────────────────────────────────────────────

async function signUp(email, password) {
  const { data, error } = await _supabase.auth.signUp({ email, password });
  if (error) throw error;
  return data.user;
}

async function signIn(email, password) {
  const { data, error } = await _supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data.user;
}

async function signOut() {
  await _supabase.auth.signOut();
  window.location.href = 'index.html';
}

async function getUser() {
  const { data: { user } } = await _supabase.auth.getUser();
  return user;
}

// ── Diagnostic results ────────────────────────────────────────────

async function saveDiagnosticResults(userId, scores, axisLabels) {
  const payload = {
    user_id:     userId,
    scores:      scores,        // objet JSON { axe1: 78, axe2: 62, ... }
    axis_labels: axisLabels,    // tableau des noms d'axes
    completed_at: new Date().toISOString(),
  };
  const { data, error } = await _supabase
    .from('diagnostic_results')
    .insert(payload)
    .select()
    .single();
  if (error) throw error;
  return data;
}

async function getDiagnosticResults(userId) {
  const { data, error } = await _supabase
    .from('diagnostic_results')
    .select('*')
    .eq('user_id', userId)
    .order('completed_at', { ascending: false });
  if (error) throw error;
  return data;
}

// ── Scenarios ─────────────────────────────────────────────────────

// Scénarios disponibles (base statique, enrichie selon le profil)
const SCENARIOS_LIBRARY = [
  {
    id: 's1',
    titre: '"Tu es trop sensible."',
    theme: 'validation_emotionnelle',
    difficulte: 1,
    description: 'Apprendre à répondre sans se fermer quand vos émotions sont minimisées.',
    reaction_auto: 'Se fermer émotionnellement et éviter le conflit.',
    reponse_saine: '"Quand mes émotions sont minimisées, je me sens incompris. J\'aimerais qu\'on puisse en parler autrement."',
  },
  {
    id: 's2',
    titre: '"Je t\'avais pourtant demandé de ne pas faire ça."',
    theme: 'limites',
    difficulte: 2,
    description: 'Poser une limite claire sans attaque ni capitulation.',
    reaction_auto: 'S\'excuser excessivement ou contre-attaquer.',
    reponse_saine: '"Tu as raison, j\'aurais dû respecter ça. Je comprends ta frustration et je vais faire attention."',
  },
  {
    id: 's3',
    titre: '"Tu ne m\'écoutes jamais."',
    theme: 'communication',
    difficulte: 2,
    description: 'Désamorcer une généralisation blessante avec empathie et clarté.',
    reaction_auto: 'Se défendre avec des contre-exemples ou se taire.',
    reponse_saine: '"Je t\'entends. Raconte-moi ce qui s\'est passé récemment qui t\'a donné ce sentiment."',
  },
  {
    id: 's4',
    titre: '"Je pensais qu\'on était amis."',
    theme: 'attachement',
    difficulte: 3,
    description: 'Clarifier les attentes émotionnelles et relationnelles sans culpabiliser ni se suradapter.',
    reaction_auto: 'Se sentir coupable et sur-compenser ou se distancer.',
    reponse_saine: '"On l\'est. Et justement parce qu\'on l\'est, je veux être honnête sur ce que je peux donner en ce moment."',
  },
  {
    id: 's5',
    titre: '"Tu fais toujours ça."',
    theme: 'communication',
    difficulte: 2,
    description: 'Répondre à une généralisation sans entrer dans une logique défensive.',
    reaction_auto: 'Nier ou ressortir des contre-exemples pour se défendre.',
    reponse_saine: '"J\'entends que ça t\'arrive souvent de vivre ça avec moi. C\'est quoi le dernier exemple qui t\'a touché ?"',
  },
  {
    id: 's6',
    titre: '"Si tu m\'aimais vraiment, tu ferais ça pour moi."',
    theme: 'limites',
    difficulte: 3,
    description: 'Identifier et déjouer la manipulation affective sans rupture.',
    reaction_auto: 'Céder par culpabilité ou se braquer complètement.',
    reponse_saine: '"Mon amour pour toi ne dépend pas de cette action. Mais je veux comprendre pourquoi c\'est important pour toi."',
  },
  {
    id: 's7',
    titre: '"Je vais bien." (alors que manifestement non)',
    theme: 'empathie',
    difficulte: 2,
    description: 'Créer un espace sécurisant pour que l\'autre puisse s\'ouvrir.',
    reaction_auto: 'Prendre la réponse au pied de la lettre ou insister maladroitement.',
    reponse_saine: '"Je te crois. Et si un jour tu as envie de parler, je suis là sans jugement."',
  },
  {
    id: 's8',
    titre: '"Tu m\'as blessé(e) l\'autre jour."',
    theme: 'validation_emotionnelle',
    difficulte: 3,
    description: 'Accueillir une plainte sans se défendre, s\'effondrer ou minimiser.',
    reaction_auto: 'Justifier son comportement immédiatement ou s\'excuser sans comprendre.',
    reponse_saine: '"Merci de me le dire. Je veux comprendre ce que j\'ai fait pour que tu te sentes ainsi."',
  },
];

// Assigne les scénarios recommandés selon le profil (scores)
function recommendScenarios(scores) {
  // scores = { axe1: pct, axe2: pct, ... }
  // Logique simple : prioriser selon les axes dominants
  const mapping = {
    axe1: ['attachement', 'validation_emotionnelle'],
    axe2: ['limites', 'communication'],
    axe3: ['communication', 'empathie'],
    axe4: ['limites', 'attachement'],
    axe5: ['empathie', 'validation_emotionnelle'],
  };

  let recommended = new Set();
  Object.entries(scores).forEach(([axe, pct]) => {
    if (pct > 50 && mapping[axe]) {
      mapping[axe].forEach(theme => {
        SCENARIOS_LIBRARY
          .filter(s => s.theme === theme)
          .forEach(s => recommended.add(s.id));
      });
    }
  });

  // Si pas assez, compléter avec les premiers
  if (recommended.size < 3) {
    SCENARIOS_LIBRARY.slice(0, 4).forEach(s => recommended.add(s.id));
  }

  return SCENARIOS_LIBRARY
    .filter(s => recommended.has(s.id))
    .sort((a, b) => a.difficulte - b.difficulte);
}

async function saveUserScenarios(userId, diagnosticId, scores) {
  const recommended = recommendScenarios(scores);
  const rows = recommended.map((s, i) => ({
    user_id:       userId,
    diagnostic_id: diagnosticId,
    scenario_id:   s.id,
    titre:         s.titre,
    theme:         s.theme,
    difficulte:    s.difficulte,
    description:   s.description,
    reaction_auto: s.reaction_auto,
    reponse_saine: s.reponse_saine,
    statut:        i === 0 ? 'disponible' : 'verrouille',
    ordre:         i,
  }));

  const { data, error } = await _supabase
    .from('user_scenarios')
    .insert(rows)
    .select();
  if (error) throw error;
  return data;
}

async function getUserScenarios(userId) {
  const { data, error } = await _supabase
    .from('user_scenarios')
    .select('*')
    .eq('user_id', userId)
    .order('ordre', { ascending: true });
  if (error) throw error;
  return data;
}

async function updateScenarioStatus(scenarioRowId, statut) {
  const { error } = await _supabase
    .from('user_scenarios')
    .update({ statut, updated_at: new Date().toISOString() })
    .eq('id', scenarioRowId);
  if (error) throw error;
}
